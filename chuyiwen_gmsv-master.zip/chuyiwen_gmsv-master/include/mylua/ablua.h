#ifndef __ABLUA_H__
#define __ABLUA_H__

void LoadAllbluesLUA(char *path);
void ReLoadAllbluesLUA();
void NewLoadAllbluesLUA(char *filename);

#endif
