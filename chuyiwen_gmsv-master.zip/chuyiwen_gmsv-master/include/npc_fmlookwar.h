#ifdef	_FM_NPC_LOOK_WAR
void NPC_FmLookWarManTalked( int meindex, int talkerindex, char *msg, int color );
BOOL NPC_FmLookWarManInit( int meindex );
void NPC_FmLookWarManWindowTalked( int meindex, int talkerindex, int seqno, int select, char *data);
void NPC_FmLookWarManLoop( int meindex);
#endif
