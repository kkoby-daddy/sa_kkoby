

void NPC_ItemVippointShopTalked( int meindex , int talkerindex , char *msg ,
                     int color );
BOOL NPC_ItemVippointShopInit( int meindex );
void NPC_ItemVippointShopWindowTalked( int meindex, int talkerindex, int seqno, int select, char *data);
void NPC_ItemVippointShopLooked( int meindex , int lookedindex);


 /*__NPC_ITEMSHOP_H__*/
