#ifdef	_FM_NPC_LOOK_WAR1
void NPC_FmLookWarMan1Talked( int meindex, int talkerindex, char *msg, int color );
BOOL NPC_FmLookWarMan1Init( int meindex );
void NPC_FmLookWarMan1WindowTalked( int meindex, int talkerindex, int seqno, int select, char *data);
void NPC_FmLookWarMan1Loop( int meindex);
#endif
