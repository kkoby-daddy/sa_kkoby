#ifndef __MAGIC_FIELD_H__
#define __MAGIC_FIELD_H__

/* 白奴□伙玉匹银迕允月热诸 */

int MAGIC_Recovery_Field( int charaindex, int magicindex);
int MAGIC_OtherRecovery_Field( int charaindex, int toindex, int magicindex);

#endif 

