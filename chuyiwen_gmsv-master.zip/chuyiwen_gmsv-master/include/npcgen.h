#ifndef __NPCGEN_H__
#define __NPCGEN_H__


void NPC_generateLoop( BOOL FlgInit );

EXTERN int all_nosee;		/* ㄠ及凛｛蝈化及衬毛 no_see 卞 */
EXTERN int all_nobody;		/* ㄠ及凛｛蝈化及衬毛 no_body 卞 */
EXTERN int one_loop_born;	/* ㄠ伙□皿匹  嫖戏心请允醒 oneloop_born */


#endif  
/*__NPCGEN_H__*/
