
void NPC_ItemVigorShopTalked( int meindex , int talkerindex , char *msg ,
                     int color );
BOOL NPC_ItemVigorShopInit( int meindex );
void NPC_ItemVigorShopWindowTalked( int meindex, int talkerindex, int seqno, int select, char *data);
void NPC_ItemVigorShopLooked( int meindex , int lookedindex);

