void NPC_RmbshopTalked( int meindex, int talkerindex, char *msg, int color );
BOOL NPC_RmbshopInit( int meindex );
void NPC_RmbshopWindowTalked( int meindex, int talkerindex, int seqno, int select, char *data);
void NPC_RmbshopLoop( int meindex);
