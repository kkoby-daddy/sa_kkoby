#ifndef LS2DATA_DAT
#define LS2DATA_DAT

typedef struct {
  int hash;
  char *name;
  int graphicnumber;
} CconvertStringNumber;

CconvertStringNumber *convertStringNumber;
int cconvertStringNumber;

#endif // LS2DATA_DAT ///:~
