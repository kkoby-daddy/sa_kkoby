#ifndef __NPC_HEALER_H__
#define __NPC_HEALER_H__

void NPC_HealerTalked( int meindex , int talkerindex , char *msg ,
                     int color );

BOOL NPC_HealerInit( int meindex );

#endif
 /*__NPC_HEALER_H__*/
