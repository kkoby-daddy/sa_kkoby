
void NPC_PetSkillDelShopTalked( int meindex , int talkerindex , char *msg ,
                     int color );
BOOL NPC_PetSkillDelShopInit( int meindex );
void NPC_PetSkillDelShopWindowTalked( int meindex, int talkerindex, int seqno, int select, char *data);
void NPC_PetSkillDelShopLooked( int meindex , int lookedindex);

void NPC_PetSkillDelMakeStr(int meindex,int toindex,int select);

 /*__NPC_WINDOWPETSKILLSHOP_H__*/
