BOOL NPC_ItemupManInit( int meindex );
void NPC_ItemupManTalked( int meindex, int talkerindex, char *msg, int color );
void NPC_ItemupManWindowTalked( int meindex, int talkerindex, int seqno,
								int select, char *data);
void NPC_ItemupManLoop( int meindex);


