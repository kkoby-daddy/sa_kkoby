#ifndef __NPC_MIC_H__
#define __NPC_MIC_H__

BOOL NPC_MicInit(int meindex );
void NPC_MicTalked( int meindex , int talkerindex , char *msg , int color );

#endif
 /*__NPC_MIC_H__*/

