#ifndef _ANIM_TBL_H_
#define _ANIM_TBL_H_

//#define SPRSTART			30000		// SPR犯□正及铵引曰及  寞
#define SPRSTART			100000		// SPR犯□正及铵引曰及  寞

// 平乓仿
#define SPR_001em			100000		//	阂间裆ㄠ	豳澎
#define SPR_001ax			100001		// 			  
#define SPR_001cl			100002		//			仇氏徇
#define SPR_001sp			100003		//			键
#define SPR_001bw			100004		//			菰

#define SPR_002em			100005		//	阂间裆ㄠ	豳澎
#define SPR_002ax			100006		// 			  
#define SPR_002cl			100007		//			仇氏徇
#define SPR_002sp			100008		//			键
#define SPR_002bw			100009		//			菰

#define SPR_003em			100010		//	阂间裆ㄠ	豳澎
#define SPR_003ax			100011		// 			  
#define SPR_003cl			100012		//			仇氏徇
#define SPR_003sp			100013		//			键
#define SPR_003bw			100014		//			菰

#define SPR_004em			100015		//	阂间裆ㄠ	豳澎
#define SPR_004ax			100016		// 			  
#define SPR_004cl			100017		//			仇氏徇
#define SPR_004sp			100018		//			键
#define SPR_004bw			100019		//			菰

#define SPR_011em			100020		//	剂  ㄠ		豳澎
#define SPR_011ax			100021		// 			  
#define SPR_011cl			100022		//			仇氏徇
#define SPR_011sp			100023		//			键
#define SPR_011bw			100024		//			菰

#define SPR_012em			100025		//	剂  ㄠ		豳澎
#define SPR_012ax			100026		// 			  
#define SPR_012cl			100027		//			仇氏徇
#define SPR_012sp			100028		//			键
#define SPR_012bw			100029		//			菰

#define SPR_013em			100030		//	剂  ㄠ		豳澎
#define SPR_013ax			100031		// 			  
#define SPR_013cl			100032		//			仇氏徇
#define SPR_013sp			100033		//			键
#define SPR_013bw			100034		//			菰

#define SPR_014em			100035		//	剂  ㄠ		豳澎
#define SPR_014ax			100036		// 			  
#define SPR_014cl			100037		//			仇氏徇
#define SPR_014sp			100038		//			键
#define SPR_014bw			100039		//			菰

#define SPR_021em			100040		//	剂  ㄡ		豳澎
#define SPR_021ax			100041		// 			  
#define SPR_021cl			100042		//			仇氏徇
#define SPR_021sp			100043		//			键
#define SPR_021bw			100044		//			菰

#define SPR_022em			100045
#define SPR_022ax			100046
#define SPR_022cl			100047
#define SPR_022sp			100048
#define SPR_022bw			100049

#define SPR_023em			100050
#define SPR_023ax			100051
#define SPR_023cl			100052
#define SPR_023sp			100053
#define SPR_023bw			100054

#define SPR_024em			100055
#define SPR_024ax			100056
#define SPR_024cl			100057
#define SPR_024sp			100058
#define SPR_024bw			100059

#define SPR_031em			100060		//	剂  ㄢ		豳澎
#define SPR_031ax			100061		// 			  
#define SPR_031cl			100062		//			仇氏徇
#define SPR_031sp			100063		//			键
#define SPR_031bw			100064		//			菰

#define SPR_032em			100065
#define SPR_032ax			100066
#define SPR_032cl			100067
#define SPR_032sp			100068
#define SPR_032bw			100069

#define SPR_033em			100070
#define SPR_033ax			100071
#define SPR_033cl			100072
#define SPR_033sp			100073
#define SPR_033bw			100074

#define SPR_034em			100075
#define SPR_034ax			100076
#define SPR_034cl			100077
#define SPR_034sp			100078
#define SPR_034bw			100079

#define SPR_041em			100080		//	敛  ㄠ		豳澎
#define SPR_041ax			100081		// 			  
#define SPR_041cl			100082		//			仇氏徇
#define SPR_041sp			100083		//			键
#define SPR_041bw			100084		//			菰

#define SPR_042em			100085
#define SPR_042ax			100086
#define SPR_042cl			100087
#define SPR_042sp			100088
#define SPR_042bw			100089

#define SPR_043em			100090
#define SPR_043ax			100091
#define SPR_043cl			100092
#define SPR_043sp			100093
#define SPR_043bw			100094

#define SPR_044em			100095
#define SPR_044ax			100096
#define SPR_044cl			100097
#define SPR_044sp			100098
#define SPR_044bw			100099

#define SPR_051em			100100		//	敛  ㄡ		豳澎
#define SPR_051ax			100101		// 			  
#define SPR_051cl			100102		//			仇氏徇
#define SPR_051sp			100103		//			键
#define SPR_051bw			100104		//			菰

#define SPR_052em			100105
#define SPR_052ax			100106
#define SPR_052cl			100107
#define SPR_052sp			100108
#define SPR_052bw			100109

#define SPR_053em			100110
#define SPR_053ax			100111
#define SPR_053cl			100112
#define SPR_053sp			100113
#define SPR_053bw			100114

#define SPR_054em			100115
#define SPR_054ax			100116
#define SPR_054cl			100117
#define SPR_054sp			100118
#define SPR_054bw			100119

#define SPR_061em			100120		//	阂间辉ㄠ		豳澎
#define SPR_061ax			100121		// 			  
#define SPR_061cl			100122		//			仇氏徇
#define SPR_061sp			100123		//			键
#define SPR_061bw			100124		//			菰

#define SPR_062em			100125
#define SPR_062ax			100126
#define SPR_062cl			100127
#define SPR_062sp			100128
#define SPR_062bw			100129

#define SPR_063em			100130
#define SPR_063ax			100131
#define SPR_063cl			100132
#define SPR_063sp			100133
#define SPR_063bw			100134

#define SPR_064em			100135
#define SPR_064ax			100136
#define SPR_064cl			100137
#define SPR_064sp			100138
#define SPR_064bw			100139

#define SPR_071em			100140		//	剂辉ㄠㄠ	豳澎
#define SPR_071ax			100141		// 			  
#define SPR_071cl			100142		//			仇氏徇
#define SPR_071sp			100143		//			键
#define SPR_071bw			100144		//			菰

#define SPR_072em			100145
#define SPR_072ax			100146
#define SPR_072cl			100147
#define SPR_072sp			100148
#define SPR_072bw			100149

#define SPR_073em			100150
#define SPR_073ax			100151
#define SPR_073cl			100152
#define SPR_073sp			100153
#define SPR_073bw			100154

#define SPR_074em			100155
#define SPR_074ax			100156
#define SPR_074cl			100157
#define SPR_074sp			100158
#define SPR_074bw			100159

#define SPR_081em			100160		//	剂辉ㄡ		豳澎
#define SPR_081ax			100161		// 			  
#define SPR_081cl			100162		//			仇氏徇
#define SPR_081sp			100163		//			键
#define SPR_081bw			100164		//			菰

#define SPR_082em			100165
#define SPR_082ax			100166
#define SPR_082cl			100167
#define SPR_082sp			100168
#define SPR_082bw			100169

#define SPR_083em			100170
#define SPR_083ax			100171
#define SPR_083cl			100172
#define SPR_083sp			100173
#define SPR_083bw			100174

#define SPR_084em			100175
#define SPR_084ax			100176
#define SPR_084cl			100177
#define SPR_084sp			100178
#define SPR_084bw			100179

#define SPR_091em			100180		//	剂辉ㄢ		豳澎
#define SPR_091ax			100181		// 			  
#define SPR_091cl			100182		//			仇氏徇
#define SPR_091sp			100183		//			键
#define SPR_091bw			100184		//			菰

#define SPR_092em			100185
#define SPR_092ax			100186
#define SPR_092cl			100187
#define SPR_092sp			100188
#define SPR_092bw			100189

#define SPR_093em			100190
#define SPR_093ax			100191
#define SPR_093cl			100192
#define SPR_093sp			100193
#define SPR_093bw			100194

#define SPR_094em			100195
#define SPR_094ax			100196
#define SPR_094cl			100197
#define SPR_094sp			100198
#define SPR_094bw			100199

#define SPR_101em			100200		//	辉岭ㄠ		豳澎
#define SPR_101ax			100201		// 			  
#define SPR_101cl			100202		//			仇氏徇
#define SPR_101sp			100203		//			键
#define SPR_101bw			100204		//			菰

#define SPR_102em			100205
#define SPR_102ax			100206
#define SPR_102cl			100207
#define SPR_102sp			100208
#define SPR_102bw			100209

#define SPR_103em			100210
#define SPR_103ax			100211
#define SPR_103cl			100212
#define SPR_103sp			100213
#define SPR_103bw			100214

#define SPR_104em			100215
#define SPR_104ax			100216
#define SPR_104cl			100217
#define SPR_104sp			100218
#define SPR_104bw			100219

#define SPR_111em			100220		//	辉岭ㄡ		豳澎
#define SPR_111ax			100221		// 			  
#define SPR_111cl			100222		//			仇氏徇
#define SPR_111sp			100223		//			键
#define SPR_111bw			100224		//			菰

#define SPR_112em			100225
#define SPR_112ax			100226
#define SPR_112cl			100227
#define SPR_112sp			100228
#define SPR_112bw			100229

#define SPR_113em			100230
#define SPR_113ax			100231
#define SPR_113cl			100232
#define SPR_113sp			100233
#define SPR_113bw			100234

#define SPR_114em			100235
#define SPR_114ax			100236
#define SPR_114cl			100237
#define SPR_114sp			100238
#define SPR_114bw			100239


// 矢永玄  衬  平乓仿
#define SPR_pet001			100250		//	它□伉
#define SPR_pet002			100251		//	它伉它伉
#define SPR_pet003			100252		//	它伉旦正奶件
#define SPR_pet004			100253		//	它伉皮伙

#define SPR_pet011			100254		//	皮□申奴
#define SPR_pet012			100255		//	打□伙玉皮□奶
#define SPR_pet013			100256		//	皮□奶
#define SPR_pet014			100257		//	皮奶□申□
#define SPR_pet015			100258		//	市□皮奶

#define SPR_pet021			100259		//	幼乓立□
#define SPR_pet022			100260		//	幼乓申□
#define SPR_pet023			100261		//	幼乓申左
#define SPR_pet024			100262		//	幼乓□旦

#define SPR_pet031			100263		//	它禾禾
#define SPR_pet032			100264		//	它奴它奴
#define SPR_pet033			100265		//	它布伙□
#define SPR_pet034			100266		//	它奴□田

#define SPR_pet041			100267		//	矛夫□件
#define SPR_pet042			100268		//	矛夫夫永弁
#define SPR_pet043			100269		//	矛夫禾永弁伙
#define SPR_pet044			100270		//	矛夫禾伉

#define SPR_pet051			100271		//	市丢用玉件
#define SPR_pet052			100272		//	市仿打
#define SPR_pet053			100273		//	乩玉市丢
#define SPR_pet054			100274		//	市仿打伙

#define SPR_pet061			100275		//	生打旦
#define SPR_pet062			100276		//	生幼乓旦
#define SPR_pet063			100277		//	正夫打件
#define SPR_pet064			100278		//	母永弁伙

#define SPR_pet071			100279		//	仿幼伙打
#define SPR_pet072			100280		//	白田田
#define SPR_pet073			100281		//	玄扔平件弘
#define SPR_pet074			100282		//	伙瓦  旦

#define SPR_pet081			100283		//	伙瓦  旦
#define SPR_pet082			100284		//	市正伙市旦
#define SPR_pet083			100285		//	弁奶永正
#define SPR_pet084			100286		//	戊夫幼乓旦

#define SPR_pet091			100287		//	伉未用玉件
#define SPR_pet092			100288		//	乩件幼夫旦
#define SPR_pet093			100289		//	田件示夫旦
#define SPR_pet094			100290		//	田件幼□用

#define SPR_pet101			100291		//	弁伊伙
#define SPR_pet102			100292		//	弁弁伙
#define SPR_pet103			100293		//	平亦夫伙
#define SPR_pet104			100294		//	伉旦平□

#define SPR_pet111			100295		//	市申永玄
#define SPR_pet112			100296		//	弗奶申□
#define SPR_pet113			100297		//	平亘□奶
#define SPR_pet114			100298		//	平乓申永玄

#define SPR_pet121			100299		//	卅仄
#define SPR_pet122			100300		//	卅仄
#define SPR_pet123			100301		//	卅仄
#define SPR_pet124			100302		//	卅仄

#define SPR_pet131			100303		//	卅仄
#define SPR_pet132			100304		//	卅仄
#define SPR_pet133			100305		//	卅仄
#define SPR_pet134			100306		//	卅仄

#define SPR_pet141			100307		//	打伙玉件
#define SPR_pet142			100308		//	幼仿玉件
#define SPR_pet143			100309		//	幼仿打伙打件
#define SPR_pet144			100310		//	打伙□打

#define SPR_pet151			100311		//	卅仄
#define SPR_pet152			100312		//	卅仄
#define SPR_pet153			100313		//	卅仄
#define SPR_pet154			100314		//	卅仄

#define SPR_pet161			100315		//	卅仄
#define SPR_pet162			100316		//	卅仄
#define SPR_pet163			100317		//	卅仄
#define SPR_pet164			100318		//	卅仄

#define SPR_pet171			100319		//	甲亘□示
#define SPR_pet172			100320		//	布仿示旦
#define SPR_pet173			100321		//	皿弁皿弁
#define SPR_pet174			100322		//	玄夫□斥乓

#define SPR_pet181			100323		//	石夫□伙
#define SPR_pet182			100324		//	弁弁□伙
#define SPR_pet183			100325		//	伙田田
#define SPR_pet184			100326		//	弁伙□田

#define SPR_pet191			100327		//	矛伙布□
#define SPR_pet192			100328		//	矛伙奶布□
#define SPR_pet193			100329		//	打伙扑旦
#define SPR_pet194			100330		//	平件弘扔□矛伙

#define SPR_pet201			100331		//	卅仄
#define SPR_pet202			100332		//	卅仄
#define SPR_pet203			100333		//	卅仄
#define SPR_pet204			100334		//	卅仄

#define SPR_pet211			100335		//	玄伉用皿旦
#define SPR_pet212			100336		//	矢件正旦
#define SPR_pet213			100337		//	玄伉弗仿□
#define SPR_pet214			100338		//	玄夫皿旦

#define SPR_pet221			100339		//	戊田件弗旦
#define SPR_pet222			100340		//	斥乓弘仿
#define SPR_pet223			100341		//	斥乓□弘
#define SPR_pet224			100342		//	田件斥□

#define SPR_pet231			100343		//	幼布夫旦
#define SPR_pet232			100344		//	幼□瓜
#define SPR_pet233			100345		//	幼布件示旦
#define SPR_pet234			100346		//	布布幼件示

#define SPR_pet241			100347		//	由□平□
#define SPR_pet242			100348		//	丞□奶□
#define SPR_pet243			100349		//	扑示□术
#define SPR_pet244			100350		//	玄伙□禾□

#define SPR_pet251			100351		//	皮夫件玄旦
#define SPR_pet252			100352		//	皮伉件  旦
#define SPR_pet253			100353		//	皮仿平玄旦
#define SPR_pet254			100354		//	旦  件玄旦

#define SPR_pet261			100355		//	穴件乒□
#define SPR_pet262			100356		//	件乒乒
#define SPR_pet263			100357		//	穴乒瓜旦
#define SPR_pet264			100358		//	穴件乒夫旦

#define SPR_pet271			100359		//	  仿打件
#define SPR_pet272			100360		//	用布夫件
#define SPR_pet273			100361		//	斥乓田打件
#define SPR_pet274			100362		//	玉仿疋旦

#define SPR_pet281			100363		//	卅仄
#define SPR_pet282			100364		//	卅仄
#define SPR_pet283			100365		//	卅仄
#define SPR_pet284			100366		//	卅仄

#define SPR_pet291			100367		//	正永平□
#define SPR_pet292			100368		//	弁弁夫旦
#define SPR_pet293			100369		//	石伙永弁
#define SPR_pet294			100370		//	平奴□示□

#define SPR_pet301			100371		//	左布夫旦
#define SPR_pet302			100372		//	札犯奴用旦
#define SPR_pet303			100373		//	由玉仿件
#define SPR_pet304			100374		//	  仿札奶玉

#define SPR_pet311			100375		//	皿奶玄
#define SPR_pet312			100376		//	乒瓜扑□皿
#define SPR_pet313			100377		//	市奶石□件
#define SPR_pet314			100378		//	仿奶石□件

#define SPR_pet321			100379		//	旦玄仿斥玉件
#define SPR_pet322			100380		//	扒丢夫旦
#define SPR_pet323			100381		//	失伉必用旦
#define SPR_pet324			100382		//	母奶用夫旦
#define SPR_pet325			100383		//	仿戊夫旦

#define SPR_pet331			100384		//	田夫夫弁旦
#define SPR_pet332			100385		//	仿件矛伙旦
#define SPR_pet333			100386		//	戊伉玄夫旦
#define SPR_pet334			100387		//	用□旦玄夫旦

// 蕙筋馨笛矢永玄
#define SPR_pet005			100388		//	幕掩
#define SPR_pet085			100389		//	港市正伙市旦
#define SPR_pet086			100390		//	  弁奶永正
#define SPR_pet087			100391		//	皮仿永弁戊夫幼乓旦
#define SPR_pet088			100392		//	失旦白央伙玄夫幼失件
#define SPR_pet065			100393		//	氘箪岭生打旦
#define SPR_pet095			100394		//	氘箪岭伉未用玉件
#define SPR_pet175			100395		//	氘箪岭申亘□示
#define SPR_pet255			100396		//	氘箪岭皮夫件玄旦

// 蕙筋馨笛皿伊奶乩□平乓仿
#define SPR_121em			100400		//	失白夫ㄠ	豳澎
#define SPR_121ax			100401		//			  
#define SPR_121cl			100402		//			轺徇
#define SPR_121sp			100403		//			键
#define SPR_121bw			100404		//			菰

#define SPR_122em			100405		//	失白夫ㄡ	豳澎
#define SPR_122ax			100406		//			  
#define SPR_122cl			100407		//			轺徇
#define SPR_122sp			100408		//			键
#define SPR_122bw			100409		//			菰

#define SPR_123em			100410		//	失白夫ㄢ	豳澎
#define SPR_123ax			100411		//			  
#define SPR_123cl			100412		//			轺徇
#define SPR_123sp			100413		//			键
#define SPR_123bw			100414		//			菰

#define SPR_124em			100415		//	失白夫ㄣ	豳澎
#define SPR_124ax			100416		//			  
#define SPR_124cl			100417		//			轺徇
#define SPR_124sp			100418		//			键
#define SPR_124bw			100419		//			菰

#define SPR_131em			100420		//	      ㄠ	豳澎
#define SPR_131ax			100421		//			  
#define SPR_131cl			100422		//			轺徇
#define SPR_131sp			100423		//			键
#define SPR_131bw			100424		//			菰

#define SPR_132em			100425		//	      ㄡ	豳澎
#define SPR_132ax			100426		//			  
#define SPR_132cl			100427		//			轺徇
#define SPR_132sp			100428		//			键
#define SPR_132bw			100429		//			菰

#define SPR_pet315			100430		//	由件母石□件

#define SPR_141em			100431		//	必件今氏ㄠ	豳澎
#define SPR_141ax			100432		//			  
#define SPR_141cl			100433		//			轺徇
#define SPR_141sp			100434		//			键
#define SPR_141bw			100435		//			菰

#define SPR_142em			100436		//	必件今氏ㄡ	豳澎
#define SPR_142ax			100437		//			  
#define SPR_142cl			100438		//			轺徇
#define SPR_142sp			100439		//			键
#define SPR_142bw			100440		//			菰

#define SPR_133em			100441		//	      ㄢ	豳澎
#define SPR_133ax			100442		//			  
#define SPR_133cl			100443		//			轺徇
#define SPR_133sp			100444		//			键
#define SPR_133bw			100445		//			菰

#define SPR_151em			100446		//	剂辉ㄠㄤ	豳澎
#define SPR_151ax			100447		// 			  
#define SPR_151cl			100448		//			仇氏徇
#define SPR_151sp			100449		//			键
#define SPR_151bw			100450		//			菰

#define SPR_152em			100451
#define SPR_152ax			100452
#define SPR_152cl			100453
#define SPR_152sp			100454
#define SPR_152bw			100455

#define SPR_161em			100456		//	剂辉ㄠㄥ	豳澎
#define SPR_161ax			100457		// 			  
#define SPR_161cl			100458		//			仇氏徇
#define SPR_161sp			100459		//			键
#define SPR_161bw			100460		//			菰

#define SPR_162em			100461
#define SPR_162ax			100462
#define SPR_162cl			100463
#define SPR_162sp			100464
#define SPR_162bw			100465

//备潘失瓦丢□扑亦件
#define SPR_leader			100500		//	伉□母□穴□弁失瓦丢□扑亦件
#define SPR_star			100501		//	夭方夭方及弥穴□弁失瓦丢
#define SPR_boomerang		100502		//	皮□丢仿件及失瓦丢□扑亦件
#define SPR_stornbomb		100503		//	檗及祯仃失瓦丢□扑亦件
#define SPR_ono				100504		//	髑仆  失瓦丢□扑亦件
#define SPR_onokage			100505		//	髑仆  及排仃失瓦丢□扑亦件
#define SPR_isiware			100506		//	檗喃木失瓦丢□扑亦件
#define SPR_mail			100507		//	丢□伙邋耨失瓦丢□扑亦件
//躲绊失瓦丢
#define SPR_stone			100550		//	檗祭躲绊失瓦丢
#define SPR_shock			100551		//	    躲绊失瓦丢
#define SPR_drunk			100552		//	办中躲绊失瓦丢
#define SPR_sleep			100553		//	戽曰躲绊失瓦丢
#define SPR_conf			100554		//	渔刭躲绊失瓦丢
#define SPR_poison			100555		//	  躲绊失瓦丢
#define SPR_zokusei			100556		//	箪岭  晶躲绊失瓦丢
//热诸巨白尼弁玄失瓦丢□扑亦件
#define SPR_effect01		100600		//	热诸失瓦丢□扑亦件
#define SPR_heal			100601		//	热诸失瓦丢□扑亦件  荚汊ㄠ  
#define SPR_heal2			100602		//	热诸失瓦丢□扑亦件  荚汊ㄡ  
#define SPR_heal3			100603		//	热诸失瓦丢□扑亦件  荚汊ㄢ  
#define SPR_tyusya			100604		//	热诸失瓦丢□扑亦件  旦  □正旦唱橘荚汊  
#define SPR_hoshi			100605		//	热诸毛井仃日木凶午五及失瓦丢□扑亦件
#define SPR_kyu				100606		//	旦  □正旦荚汊热诸毛井仃日木凶午五及失瓦丢□扑亦件
#define SPR_fukkatu1		100607		//	汊唾  ㄠ  毛井仃日木凶午五及失瓦丢□扑亦件
#define SPR_fukkatu2		100608		//	汊唾  ㄡ  毛井仃日木凶午五及失瓦丢□扑亦件
#define SPR_fukkatu3		100609		//	汊唾  ㄢ  毛井仃日木凶午五及失瓦丢□扑亦件
#define SPR_difence			100610		//	  豢烟热诸毛井仃日木凶午五及失瓦丢□扑亦件
#define SPR_item			100611		//	失奶  丞毛银迕仄凶午五及失瓦丢□扑亦件
#define SPR_item3			100612		//	失奶  丞毛银迕仄凶午五及失瓦丢□扑亦件
//  豢烟热诸失瓦丢□扑亦件
#define SPR_mirror			100650		//	  椁失瓦丢□扑亦件
#define SPR_barrior			100651		//	田伉失失瓦丢□扑亦件

// 仇仇井日反｝      犯□正匹反卅中 ****************************************************/
#define CG_INVISIBLE				99	// 仇木动票反    卞    今木卅中
//#define CG_GRID_CURSOR		99
#define CG_MOUSE_CURSOR		25000
#define CG_GRID_CURSOR		25001

// 皿伊奶乩□及田玄伙示正件
#define CG_BTL_BUTTON_ATTACK_UP		25100
#define CG_BTL_BUTTON_ATTACK_DOWN	25101
#define CG_BTL_BUTTON_JUJUTU_UP		25102
#define CG_BTL_BUTTON_JUJUTU_DOWN	25103
#define CG_BTL_BUTTON_CAPTURE_UP	25104
#define CG_BTL_BUTTON_CAPTURE_DOWN	25105
#define CG_BTL_BUTTON_HELP_UP		25106
#define CG_BTL_BUTTON_HELP_DOWN		25107
#define CG_BTL_BUTTON_GUARD_UP		25108
#define CG_BTL_BUTTON_GUARD_DOWN	25109
#define CG_BTL_BUTTON_ITEM_UP		25110
#define CG_BTL_BUTTON_ITEM_DOWN		25111
#define CG_BTL_BUTTON_PET_UP		25112
#define CG_BTL_BUTTON_PET_DOWN		25113
#define CG_BTL_BUTTON_ESCAPE_UP		25114
#define CG_BTL_BUTTON_ESCAPE_DOWN	25115
#define CG_BTL_BUTTON_BASE			25116	// 示正件及萝酱
#define CG_BTL_BUTTON_CROSS			25117	// －示正件

// 箪岭失奶戊件
#define CG_ATR_ICON_EARTH_BIG		25120	// ＞哗＝  
#define CG_ATR_ICON_EARTH_MDL		25121	// ＞哗＝  
#define CG_ATR_ICON_EARTH_SML		25122	// ＞哗＝凝
#define CG_ATR_ICON_WATER_BIG		25123	// ＞  ＝  
#define CG_ATR_ICON_WATER_MDL		25124	// ＞  ＝  
#define CG_ATR_ICON_WATER_SML		25125	// ＞  ＝凝
#define CG_ATR_ICON_FIRE_BIG		25126	// ＞绍＝  
#define CG_ATR_ICON_FIRE_MDL		25127	// ＞绍＝  
#define CG_ATR_ICON_FIRE_SML		25128	// ＞绍＝凝
#define CG_ATR_ICON_WIND_BIG		25129	// ＞氘＝  
#define CG_ATR_ICON_WIND_MDL		25130	// ＞氘＝  
#define CG_ATR_ICON_WIND_SML		25131	// ＞氘＝凝

// 爵    箪岭失奶戊件
#define CG_ATR_ICON_EARTH_BATTLE	25132	// ＞哗＝
#define CG_ATR_ICON_WATER_BATTLE	25133	// ＞  ＝
#define CG_ATR_ICON_FIRE_BATTLE		25134	// ＞绍＝
#define CG_ATR_ICON_WIND_BATTLE		25135	// ＞氘＝

// 矢永玄及田玄伙示正件
#define CG_PET_BTL_BUTTON_BASE		25140	// 示正件及萝酱
#define CG_PET_BTL_BUTTON_WAZA_UP	25141	//   示正件  
#define CG_PET_BTL_BUTTON_WAZA_DOWN	25142	//   示正件枭
#define CG_PET_BTL_BUTTON_CANCEL_UP	25143	// 平乓件本伙示正件  

// 甲永玄穴□弁
#define CG_HIT_MARK_00				25500	// 弥  
#define CG_HIT_MARK_01				25501	// 弥凝

#define CG_HIT_MARK_10				25502	// 敛缙
#define CG_HIT_MARK_11				25503
#define CG_HIT_MARK_12				25504

#define CG_HIT_MARK_20				25505	// 毡缙
#define CG_HIT_MARK_21				25506
#define CG_HIT_MARK_22				25507

#define CG_HIT_MARK_30				25508	//   缙
#define CG_HIT_MARK_31				25509
#define CG_HIT_MARK_32				25510

#define CG_HIT_MARK_40				25511	// 疵缙
#define CG_HIT_MARK_41				25512
#define CG_HIT_MARK_42				25513

// 酱髦
#define CG_SPEECH_BTL_OK			25520
#define CG_SPEECH_CHANGE			25521
#define CG_SPEECH_GROUP				25522
#define CG_SPEECH_SUCCESS			25523
#define CG_SPEECH_YATTA				25524
#define CG_SPEECH_HELP				25525

// 巨件市它件玄穴□弁
#define CG_VS_MARK_1A				25610
#define CG_VS_MARK_1B				25611
#define CG_VS_MARK_2A				25612
#define CG_VS_MARK_2B				25613
#define CG_VS_MARK_3A				25614
#define CG_VS_MARK_3B				25615
#define CG_VS_MARK_4A				25616
#define CG_VS_MARK_4B				25617
#define CG_VS_MARK_5A				25618
#define CG_VS_MARK_5B				25619
#define CG_VS_MARK_6A				25620
#define CG_VS_MARK_6B				25621
#define CG_VS_MARK_7A				25622
#define CG_VS_MARK_7B				25623
#define CG_VS_MARK_8A				25624
#define CG_VS_MARK_8B				25625
#define CG_VS_MARK_9A				25626
#define CG_VS_MARK_9B				25627
#define CG_VS_MARK_10A				25628
#define CG_VS_MARK_10B				25629

// 菰泫
#define CG_ARROW_00					25630
#define CG_ARROW_01					25631
#define CG_ARROW_02					25632
#define CG_ARROW_03					25633
#define CG_ARROW_04					25634
#define CG_ARROW_05					25635
#define CG_ARROW_06					25636
#define CG_ARROW_07					25637
#define CG_ARROW_08					25638
#define CG_ARROW_09					25639
#define CG_ARROW_10					25640
#define CG_ARROW_11					25641
#define CG_ARROW_12					25642
#define CG_ARROW_13					25643
#define CG_ARROW_14					25644
#define CG_ARROW_15					25645

// 市它件玄母它件醒侬
#define CG_CNT_DOWN_0				25900
#define CG_CNT_DOWN_1				25901
#define CG_CNT_DOWN_2				25902
#define CG_CNT_DOWN_3				25903
#define CG_CNT_DOWN_4				25904
#define CG_CNT_DOWN_5				25905
#define CG_CNT_DOWN_6				25906
#define CG_CNT_DOWN_7				25907
#define CG_CNT_DOWN_8				25908
#define CG_CNT_DOWN_9   			25909

//   迕它奴件玉它
#define CG_WND_G_0			26001
#define CG_WND_G_1			26002
#define CG_WND_G_2			26003
#define CG_WND_G_3			26004
#define CG_WND_G_4			26005
#define CG_WND_G_5			26006
#define CG_WND_G_6			26007
#define CG_WND_G_7			26008
#define CG_WND_G_8			26009

// 它奴件玉它正奶玄伙
#define CG_WND_TITLE_SYSTEM	26010
#define CG_WND_TITLE_LOGOUT	26011
#define CG_WND_TITLE_CHAT	26015
#define CG_WND_TITLE_BGM	26016
#define CG_WND_TITLE_SE		26017
#define CG_WND_TITLE_RESULT	26018

// 正旦弁田□
#define CG_TASK_BAR_BACK		26012

// 爵  凛及    午    田□
#define CG_BATTLE_BAR_PLAYER		26013	// 皿伊奶乩□
#define CG_BATTLE_BAR_PLAYER_2		26019	// 皿伊奶乩□
#define CG_BATTLE_BAR_PET			26014	// 职及谛
#define CG_BATTLE_BAR_PET_2			26020	// 皿伊奶乩□及矢永玄

//   迕它奴件玉它ㄡ
#define CG_WND2_G_0			26021
#define CG_WND2_G_1			26022
#define CG_WND2_G_2			26023
#define CG_WND2_G_3			26024
#define CG_WND2_G_4			26025
#define CG_WND2_G_5			26026
#define CG_WND2_G_6			26027
#define CG_WND2_G_7			26028
#define CG_WND2_G_8			26029

//   迕它奴件玉它ㄢ
#define CG_WND3_G_7			26037	// 票及心｝  侬毛藉切  户月正奶皿
#define CG_WND3_G_8			26038
#define CG_WND3_G_9			26039

//     它奴件玉它
#define CG_BTL_PET_CHANGE_WND	26040	// 爵  凛及矢永玄  木赘尹它奴件玉它
#define CG_BTL_PET_RETURN_BTN	26041	// 爵  凛及矢永玄  允示正件    迕  

//   迕示正件
#define CG_CLOSE_BTN			26042	//   元月示正件    迕  
#define CG_RETURN_BTN			26043	//   月示正件    迕  
#define CG_OK_BTN				26093	//     示正件    迕  
#define CG_CANCEL_BTN			26050	// 平乓件本伙示正件    迕  

#define CG_YES_BTN				26094	// "是"示正件
#define CG_NO_BTN				26095	// "否"示正件
#define CG_EXIT_BTN				26096	// "出现"示正件
#define CG_SEAL_BTN				26097	// "卖"示正件
#define CG_BUY_BTN				26098	// "买"示正件

// 矢永玄它奴件玉它
#define CG_PET_WND_VIEW			26044	// 矢永玄旦  □正旦域  它奴件玉它
#define CG_PET_WND_DETAIL		26045	// 矢永玄及择称它奴件玉它

#define CG_PET_WND_WAZA_BTN		26046	//   示正件    迕  
//#define CG_PREV_BTN				26047	// 蟆卞濠曰赘尹月示正件    迕  
//#define CG_NEXT_BTN				26048	// 戚卞濠曰赘尹月示正件    迕  
#define CG_NAME_CHANGE_WND		26049	//   蟆  凳它奴件玉它
//#define CG_NAME_CHANGE_BTN		26051	//   蟆  凳示正件
#define CG_NAME_CHANGE_BTN		26058	//   蟆  凳示正件  
#define CG_NAME_CHANGE_BTN_DOWN	26059	//   蟆  凳示正件枭

#define CG_PET_WND_REST_BTN		26052	// 矢永玄菱心示正件
#define CG_PET_WND_STANDBY_BTN	26053	// 矢永玄谨窗示正件
#define CG_PET_WND_BTL_BTN		26054	// 矢永玄田玄伙示正件
#define CG_PET_WND_MAIL_BTN		26055	// 矢永玄丢□伙示正件
#define CG_PET_WND_STATUS_BTN	26056	// 矢永玄择称示正件


// 失奶  丞它奴件玉它
#define CG_ITEM_WND_0		26060	// 失奶  丞它奴件玉它晓
#define CG_ITEM_WND_1		26061	// 失奶  丞它奴件玉它票
#define CG_ITEM_WND_GOLD_DROP_BTN_UP	26062	// 云嗯  午允示正件  
#define CG_ITEM_WND_GOLD_DROP_BTN_DOWN	26063	// 云嗯  午允示正件枭
#define CG_ITEM_WND_GOLD_INC_BTN_UP		26064	// 云嗯  支允示正件  
#define CG_ITEM_WND_GOLD_INC_BTN_DOWN	26065	// 云嗯  支允示正件枭
#define CG_ITEM_WND_GOLD_DEC_BTN_UP		26066	// 云嗯蛹日允示正件  
#define CG_ITEM_WND_GOLD_DEC_BTN_DOWN	26067	// 云嗯蛹日允示正件枭
#define CG_JUJUTU_WND					26068	// 热诸它奴件玉它
#define CG_ITEM_WND_JUJUTU_BTN			26069	// 失奶  丞它奴件玉它及热诸示正件
#define CG_ITEM_WND_SELECT_WND			26070	// 蓟  它奴件玉它
#define CG_STATUS_WND_GROUP_WND			26071	// 旦  □正旦域  它奴件玉它
#define CG_BTL_ITEM_WND_TITLE			26072	// 爵  凛及失奶  丞它奴件玉它正奶玄伙

// 旦  □正旦它奴件玉它
#define CG_STATUS_WND					26073	// 皿伊奶乩□旦  □正旦它奴件玉它
#define CG_STATUS_WND_VICTORY_MARK		26074	//     穴□弁
#define CG_STATUS_WND_LV_UP_POINT		26075	// 伊矛伙失永皿  侬
#define CG_STATUS_WND_UP_BTN_UP			26076	// 旦  □正旦失永皿示正件  
#define CG_STATUS_WND_UP_BTN_DOWN		26077	// 旦  □正旦失永皿示正件枭
#define CG_STATUS_WND_SHOUGOU_BTN_UP	26078	// 惫寞示正件  
#define CG_STATUS_WND_SHOUGOU_BTN_DOWN	26079	// 惫寞示正件枭
#define CG_STATUS_WND_GROUP_BTN			26080	// 弘伙□皿域  示正件

// 穴永皿它奴件玉它
#define CG_MAP_WND						26081	// 穴永皿它奴件玉它

// 丢□伙它奴件玉它
#define CG_MAIL_WND						26082	// 丢□伙它奴件玉它
#define CG_MAIL_WND_SEND_WND			26200	// 丢□伙霜耨它奴件玉它
#define CG_MAIL_WND_PET_SEND_WND		26201	// 丢□伙午矢永玄霜耨它奴件玉它
#define CG_MAIL_WND_ITEM_BTN			26202	// 失奶  丞示正件
#define CG_MAIL_WND_HISTORY_WND			26203	// 丢□伙    它奴件玉它

//#define CG_MAIL_WND_MAIL_BTN			26083	// 丢□伙示正件
#define CG_MAIL_WND_ON_LINE_SUN_BTN		26084	//     仿奶件示正件＞      ＝
#define CG_MAIL_WND_ON_LINE_MOON_BTN	26088	//     仿奶件示正件＞        ＝
#define CG_MAIL_WND_OFF_LINE_BTN		26085	//       仿奶件示正件
#define CG_MAIL_WND_MAIL_BTN			26086	//     示正件
#define CG_MAIL_WND_DELETE_BTN			26087	// 绰轮示正件
#define CG_MAIL_WND_CLEAR_BTN_UP		26172	//   懔弁伉失示正件  
#define CG_MAIL_WND_CLEAR_BTN_DOWN		26173	//   懔弁伉失示正件枭
#define CG_SEND_BTN						26099	// "送信"示正件  
#define CG_SEND_BTN_DOWN				26174	// "送信"示正件枭

// 失伙田丞它奴件玉它
#define CG_ALBUM_WND					26230	// 失伙田丞它奴件玉它
#define CG_ALBUM_WND_NEW_ICON			26231	// 蕙筋失奶戊件
#define CG_ALBUM_WND_SNAP_BTN_UP		26170	// 樟蕞毛诲月  
#define CG_ALBUM_WND_SNAP_BTN_DOWN		26171	// 樟蕞毛诲月枭

// 民乓永玄及  侬瓒  它奴件玉它
#define CG_CHAT_REGISTY_WND				26232

//   侬  曰  迕它奴件玉它
#define CG_COMMON_WIN_YORO				26090	// "可以吗"午踏井木凶它奴件玉它
#define CG_COMMON_YES_BTN				26091	// 反中示正件
#define CG_COMMON_NO_BTN				26092	// 中中尹示正件

// 白奴□伙玉    示正件  
#define CG_FIELD_MENU_LEFT				26100	// 尔晓酱甄
#define CG_FIELD_MENU_BTN_OFF			26101	// 丢瓦亘□示正件左白橇谪
#define CG_FIELD_MENU_BTN_ON			26102	// 丢瓦亘□示正件左件橇谪
#define CG_FIELD_CARD_BTN_OFF			26103	//   铜示正件左白橇谪
#define CG_FIELD_CARD_BTN_ON			26104	//   铜示正件左件橇谪
#define CG_FIELD_GROUP_BTN_OFF			26105	// 弘伙□皿示正件左白橇谪
#define CG_FIELD_GROUP_BTN_ON			26106	// 弘伙□皿示正件左件橇谪
#define CG_FIELD_MAIL_LAMP				26107	// 丢□伙熬耨仿件皿
#define CG_FIELD_MENU_RIGHT				26110	// 惘晓酱甄
#define CG_FIELD_JOIN_BTL_BTN_OFF		26111	// 辅爵示正件左白橇谪
#define CG_FIELD_JOIN_BTL_BTN_ON		26112	// 辅爵示正件左件橇谪
#define CG_FIELD_DUEL_BTN_OFF			26113	// 覆爵示正件左白橇谪
#define CG_FIELD_DUEL_BTN_ON			26114	// 覆爵示正件左件橇谪
#define CG_FIELD_ACT_BTN_OFF			26115	// 失弁扑亦件示正件左白橇谪
#define CG_FIELD_ACT_BTN_ON				26116	// 失弁扑亦件示正件左件橇谪
#define CG_FIELD_AM_PM_00				26117	// 苹’  弘仿白奴永弁
#define CG_FIELD_AM_PM_01				26118	// 苹’  弘仿白奴永弁
#define CG_FIELD_AM_PM_02				26119	// 苹’  弘仿白奴永弁
#define CG_FIELD_AM_PM_03				26120	// 苹’  弘仿白奴永弁
#define CG_FIELD_MENU_RIGHT_BACK		26121	// 惘晓酱甄及田永弁

// 矢永玄及  它奴件玉它
#define CG_PET_WAZA_WND		26130
#define CG_PET_WAZA_BAR_1	26131
#define CG_PET_WAZA_BAR_2	26132
#define CG_PET_WAZA_BAR_3	26133
#define CG_PET_WAZA_BAR_4	26134
#define CG_PET_WAZA_BAR_5	26135
#define CG_PET_WAZA_BAR_6	26136
#define CG_PET_WAZA_BAR_7	26137

// 失奶  丞扑亦永皿它奴件玉它
#define CG_ITEMSHOP_WIN			26138

//   扑亦永皿它奴件玉它
#define CG_SKILLSHOP_WIN		26139

// 引午户  中它奴件玉它
#define CG_ITEMSHOP_KOSU_WIN	26140

// 正旦弁田□示正件
#define CG_TASK_BAR_MAP_UP		26150
#define CG_TASK_BAR_MAP_DOWM	26151
#define CG_TASK_BAR_STATUS_UP	26152
#define CG_TASK_BAR_STATUS_DOWN	26153
#define CG_TASK_BAR_PET_UP		26154
#define CG_TASK_BAR_PET_DOWN	26155
#define CG_TASK_BAR_ITEM_UP		26156
#define CG_TASK_BAR_ITEM_DOWN	26157
#define CG_TASK_BAR_MAIL_UP		26158
#define CG_TASK_BAR_MAIL_DOWN	26159
#define CG_TASK_BAR_ALBUM_UP	26160
#define CG_TASK_BAR_ALBUM_DOWN	26161
#define CG_TASK_BAR_SYSTEM_UP	26162
#define CG_TASK_BAR_SYSTEM_DOWN	26163

// 蟆  示正件
#define CG_PREV_BTN				26180	// ～示正件  
#define CG_PREV_BTN_DOWN		26181	// ～示正件枭
#define CG_NEXT_BTN				26182	// ∩示正件  
#define CG_NEXT_BTN_DOWN		26183	// ∩示正件枭

#define CG_PREV_BTN2			26184	// Ｕ示正件  
#define CG_PREV_BTN2_DOWN		26185	// Ｕ示正件枭
#define CG_NEXT_BTN2			26186	// Ｖ示正件  
#define CG_NEXT_BTN2_DOWN		26187	// Ｖ示正件枭

#define CG_UP_BTN				26188	//   示正件  
#define CG_UP_BTN_DOWN			26189	//   示正件枭
#define CG_DOWN_BTN				26190	//   示正件  
#define CG_DOWN_BTN_DOWN		26191	//   示正件枭


// 失奶戊件
#define CG_ICON_FUKIDASI		26500	// 民乓永玄    凛  及蹄五请仄
#define CG_ICON_COME_ON			26501	// ＞Come On!＝
#define CG_ICON_GO				26502	// ＞Go!＝
#define CG_ICON_WATCHING		26503	// ＞Watching＝
#define CG_ICON_MISS			26504	// ＞Miss...＝
#define CG_ICON_FAIL			26505	// ＞Fail...＝
#define CG_ICON_GET				26506	// ＞Get!!＝
#define CG_ICON_COUNTER			26507	// ＞Counter!＝
#define CG_ICON_DANGER			26508	// ＞Danger!＝
#define CG_ICON_NO				26509	// ＞No!＝
#define CG_ICON_GUARD			26510	// ＞Guard!＝
#define CG_ICON_ESCAPE  		26511	// ＞Escape!＝
#define CG_ICON_CAPTURE 		26512	// ＞Capture!＝
#define CG_ICON_LEAVE			26513	// ＞Leave!＝
#define CG_ICON_GUARD_BREAK 	26514	// ＞Guard Break!＝

// 矢永玄及涌  仄弘仿白奴永弁
#define CG_NOW_PAINTING			28999

// 正奶玄伙
#define CG_LOGO				29000
#define CG_TITLE			29001
#define CG_TITLE_NAME_S		29002
#define CG_TITLE_NAME_T		29003
#define CG_TITLE_NAME_O 	29004
#define CG_TITLE_NAME_N		29005
#define CG_TITLE_NAME_E		29006
#define CG_TITLE_NAME_A		29007
#define CG_TITLE_NAME_G		29008
#define CG_TITLE_NAME_E2	29009
#define CG_TITLE_NAME		29010
#define CG_TITLE_NAME_FLASH		29011
#define CG_TITLE_NAME_FLASH1	29012
#define CG_TITLE_NAME_FLASH2	29013
#define CG_TITLE_NAME_FLASH3	29014
#define CG_TITLE_NAME_FLASH4	29015
#define CG_TITLE_NAME_FLASH5	29016
#define CG_TITLE_JSS_LOGO		29017
#define CG_TITLE_DREAM_LOGO		29018
#define CG_TITLE_NOW_LOADING	29019
#define CG_TITLE_ID_PASS		29020
#define CG_TITLE_ID_PASS_OK		29021
#define CG_TITLE_ID_PASS_QUIT	29022

// 平乓仿综岳
#define CG_CHR_MAKE_SEL_BG		29030		// 蕙筋平乓仿蓟      
#define CG_CHR_MAKE_BG			29031		// 蕙筋平乓仿由仿丢□正蕊曰坌仃    
#define CG_CHR_SEL_BG			29032		// 平乓仿弁正蓟      
#define CG_CHR_SEL_LOGIN_BTN	29033		// 夫弘奶件示正件
#define CG_CHR_SEL_NEW_BTN		29034		// 蕙筋示正件
#define CG_CHR_SEL_DEL_BTN		29035		// 绰轮示正件
#define CG_CHR_SEL_BACK_BTN		29036		//   月示正件
#define CG_CHR_MAKE_OK_BTN		29037		// 蕙筋平乓仿 瑁烂示正件
#define CG_CHR_MAKE_BACK_BTN	29038		// 蕙筋平乓仿   月示正件
#define CG_CHR_MAKE_SEL2_BG		29039		// 请褥哗蓟      
#define CG_CHR_MAKE_HOME_NAME0	29040		// 请褥哗  ＞扔丞幼伙及翘＝
#define CG_CHR_MAKE_HOME_NAME1	29041		// 请褥哗  ＞穴伉瓜旦及翘＝
#define CG_CHR_MAKE_HOME_NAME2	29042		// 请褥哗  ＞斥乓斥乓及翘＝
#define CG_CHR_MAKE_HOME_NAME3	29043		// 请褥哗  ＞市伙正□瓜及翘＝
#define CG_CHR_MAKE_EYE_SEL		29044		// 蕙筋平乓仿   ’轼蓟  
#define CG_CHR_MAKE_NOSE_SEL	29045		// 蕙筋平乓仿   ’轼蓟  
#define CG_CHR_MAKE_FACE		30000		// 平乓仿涌  飓钒铵

#endif
