#ifndef __CORRECT_BUG_H__
#define __CORRECT_BUG_H__

/* ----------------------- (开放区) ---------------------------*/ 
#define _add_item_log_name   // WON ADD 在item的log中增加item名称
#define _PETSKILLBUG         // Syu ADD 修正宠物问题
#define _FIXWOLF             // Syu ADD 修正狼人变身Bug
#define _FIXMAGICBUG         // Syu ADD 修正魔法熟练、抗性暴掉问题
#define _FIXPETFALL          // Syu ADD 修正落马术
#define _FIX_ITEMRELIFE      // WON ADD 修正替身娃娃问题
#define _FIX_SPEED_UPLEVEL   // WON ADD 修正加速
#define _FIX_PETMAIL         // WON ADD 修正宠邮
#define _FIX_EQUIP_ITEM      // WON ADD 修正道具需重新装备
#define _ADD_PETMAIL_NUM     // WON ADD 宠邮数量GM指令
#define _FIX_equipNoenemy    // WON ADD 修正太阳神首饰
#define _FIX_PETMAIL2        // WON ADD 修正宠邮2
#define _FIXITEMANISHOW      // Syu ADD 修正回合性补血装备道具骑宠时宠物不显示动画问题
#define _kr_ip               // WON ADD 不锁gm指令ip

#endif
