#ifndef _NPC_MSG_H_
#define _NPC_MSG_H_

BOOL NPC_MsgInit( int meindex );
void NPC_MsgLooked( int meindex , int lookedindex );


#endif

