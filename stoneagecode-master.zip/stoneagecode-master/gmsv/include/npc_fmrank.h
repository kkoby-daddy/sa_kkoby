void NPC_FmRankTalked( int meindex, int talkerindex, char *msg, int color );
BOOL NPC_FmRankInit( int meindex );
void NPC_FmRankWindowTalked( int meindex, int talkerindex, int seqno, int select, char *data);
void NPC_FmRankLoop( void );
