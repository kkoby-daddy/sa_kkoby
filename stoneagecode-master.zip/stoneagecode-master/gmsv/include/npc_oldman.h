#ifndef __NPC_OLDMAN_H__
#define __NPC_OLDMAN_H__


void NPC_OldmanTalked( int meindex , int talkerindex , char *msg ,
                     int color );

BOOL NPC_OldmanInit( int meindex );


#endif 
/*__NPC_OLDMAN_H__*/
