

void NPC_NewVipshopTalked( int meindex, int talkerindex, char *msg, int color );
BOOL NPC_NewVipshopInit( int meindex );
void NPC_NewVipshopWindowTalked( int meindex, int talkerindex, int seqno, int select, char *data);
void NPC_NewVipshopLoop( int meindex);


